<?=$html?>

<script type="text/javascript">
    $(document).ready(function(){
        $('.datepicker').datepicker();
        $('.chosen').chosen();
    });
</script>