    <div class="span2 main-menu-span">
        <div class="well nav-collapse sidebar-nav">
            <ul class="nav nav-tabs nav-stacked main-menu">
                <li class="nav-header hidden-tablet"><?=$loginData['complete_name']?></li>
                <li><a class="ajax-link" href="<?=ADMIN_URL?>"><i class="icon-home"></i><span class="hidden-tablet"> Dashboard</span></a></li>



                <li><a class="ajax-link" href="<?=ADMIN_URL?>items"><i class="icon-th"></i><span class="hidden-tablet"> Items </span></a></li>
                <li><a class="ajax-link" href="<?=ADMIN_URL?>products"><i class="icon-th"></i><span class="hidden-tablet"> Products </span></a></li>
                <li><a class="ajax-link" href="<?=ADMIN_URL?>expense_type"><i class="icon-th"></i><span class="hidden-tablet"> Expense Type </span></a></li>

                <li><a href="javascript:void(0)">&nbsp;</a></li>

                <li><a class="ajax-link" href="<?=ADMIN_URL?>production_team"><i class="icon-user"></i><span class="hidden-tablet"> Vendors </span></a></li>
                <li><a class="ajax-link" href="<?=ADMIN_URL?>customers"><i class="icon-user"></i><span class="hidden-tablet"> Customers </span></a></li>
                <li><a class="ajax-link" href="<?=ADMIN_URL?>clients"><i class="icon-user"></i><span class="hidden-tablet"> Suppliers </span></a></li>
                <li><a class="ajax-link" href="<?=ADMIN_URL?>staff"><i class="icon-user"></i><span class="hidden-tablet"> Staff </span></a></li>

                <li><a href="javascript:void(0)">&nbsp;</a></li>

                <li><a class="ajax-link" href="<?=ADMIN_URL?>supplier_invoice"><i class="icon-tasks"></i><span class="hidden-tablet"> Suppliers Invoice </span></a></li>
                <li><a class="ajax-link" href="<?=ADMIN_URL?>customer_invoice"><i class="icon-tasks"></i><span class="hidden-tablet"> Customer Invoice </span></a></li>
                <li><a class="ajax-link" href="<?=ADMIN_URL?>vendor_invoice"><i class="icon-tasks"></i><span class="hidden-tablet"> Vendor Invoice </span></a></li>
                <li><a class="ajax-link" href="<?=ADMIN_URL?>expense_invoice"><i class="icon-tasks"></i><span class="hidden-tablet"> Expense Invoice </span></a></li>

                <li><a href="javascript:void(0)">&nbsp;</a></li>

                <li><a class="ajax-link" href="<?=ADMIN_URL?>search_invoice"><i class="icon-tasks"></i><span class="hidden-tablet"> Search </span></a></li>
                <li><a class="ajax-link" href="<?=ADMIN_URL?>product_stock"><i class="icon-tasks"></i><span class="hidden-tablet"> Products Stock </span></a></li>
                <li><a class="ajax-link" href="<?=ADMIN_URL?>item_stock"><i class="icon-tasks"></i><span class="hidden-tablet"> Items Stock </span></a></li>

                <li><a href="javascript:void(0)">&nbsp;</a></li>

                <li><a class="ajax-link" href="<?=ADMIN_URL?>account_ledger"><i class="icon-tasks"></i><span class="hidden-tablet"> Accounts </span></a></li>
                <li><a class="ajax-link" href="<?=ADMIN_URL?>expense_ledger"><i class="icon-tasks"></i><span class="hidden-tablet"> Expense Ledger </span></a></li>
            </ul>
        </div>
    </div>