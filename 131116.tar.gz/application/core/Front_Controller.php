<?php

    class Front_Controller extends My_Controller
    {
        function __construct()
        {
            parent::__construct();
        }
    }
