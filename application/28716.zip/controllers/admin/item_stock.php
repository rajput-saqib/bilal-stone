<?php

    class Item_Stock extends Admin_Controller
    {
        var $controller = 'item_stock';
        var $id;
        var $type;

        var $table = 'invoice';
        var $table2 = 'invoice_detail';
        var $table3 = 'clients';
        var $table4 = 'products';
        var $table5 = 'items';

        var $data = array();
        var $headingText = '';

        function __construct()
        {
            parent::__construct();
            if (isset($_GET['id']))
            {
                $this->id = $this->decrypt($this->input->get('id'));
            }
            $this->data['controllerName'] = $this->controller;
        }

        function index()
        {
            $whereSearchedText = '';
            $searchedText      = $this->input->post('searchedText');
            if ($searchedText != '')
            {
                $whereSearchedText = " AND it.`name` LIKE '%" . $searchedText . "%'";
            }

            if ($this->id > 0 && $whereSearchedText == '')
            {
                $row               = $this->select('', $this->table5, 'id =' . $this->id)->row();
                $this->headingText = 'Item Name : ' . $row->name;
                $query = "SELECT i.`id`, i.`type_c` 'client_type', i.client_id, i.date, i.`type_i` 'type', i.`type_i` 'invoice_type', CONCAT('Invoice(', (i.`id`), ')') 'invoice_detail', SUM(CASE WHEN i.`type_i` = 1  THEN ii.`itemQty`  ELSE NULL END ) 'debit', TRUNCATE((pd.`quantity` * id.`qty`) / it.`qty_per_bag`, 2) 'credit', 'balance' FROM items it INNER JOIN invoice_items ii ON it.`id` = ii.`itemId` INNER JOIN invoice i ON ii.`invoiceId` = i.`id` INNER JOIN `invoice_detail` id ON ii.`invoiceDetailId` = id.`id` LEFT JOIN `products` p ON id.`product_id` = p.`id` LEFT JOIN `product_detail` pd ON p.`id` = pd.`product_id` AND pd.`status` = '1' WHERE i.`status` = '1' AND ii.`status` = '1' AND (i.`type_i` = 1 OR i.`type_i` = 3) AND ii.`itemId` = '".$this->id."' GROUP BY i.`id` ";
            }
            else
            {
                $query = "SELECT it.`id` 'id', it.`name`, CONCAT('Purchase (', SUM(CASE WHEN i.`type_i` = 1 THEN 1 ELSE 0 END),')', ' & Vendor (',SUM(CASE WHEN (i.`type_i` = 3) THEN 1 ELSE 0 END), ')') 'detail', SUM(CASE WHEN i.`type_i` = '1' THEN ii.`itemQty` END )  'remaining', CASE WHEN i.`type_i` != '1' THEN (pd.`quantity` * id.`qty`) / it.`qty_per_bag` END 'used' FROM `items` it INNER JOIN invoice_items ii ON it.`id` = ii.`itemId` INNER JOIN `invoice_detail` id ON ii.`invoiceDetailId` = id.`id` INNER JOIN invoice i ON ii.`invoiceId` = i.`id` LEFT JOIN `products` p ON id.`product_id` = p.`id` LEFT JOIN `product_detail` pd ON p.`id` = pd.`product_id` AND pd.`status` = '1' WHERE i.`status` = '1' AND id.`status` = '1' AND ii.`status` = '1' AND (i.`type_i` = 1 OR i.`type_i` = 3) $whereSearchedText GROUP BY it.`id` ORDER BY it.`name`";
            }

            $temp              = new template();
            $temp->query       = $query;
            $temp->action      = false;
            $temp->controller  = $this->controller;
            $temp->headingText = $this->headingText;
            $pageNo = $this->getUrlValue(4);
            if (!empty($pageNo))
            {
                $temp->pageNo = $pageNo;
            }
            $this->loadView($temp->pagination(), $this->data);
        }
    }


?>