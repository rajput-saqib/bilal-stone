<?php

    class Product_Stock extends Admin_Controller
    {
        var $controller = 'product_stock';
        var $id;
        var $type;

        var $table = 'invoice';
        var $table2 = 'invoice_detail';
        var $table3 = 'clients';
        var $table4 = 'products';
        var $table5 = 'items';

        var $data = array();
        var $headingText = '';

        function __construct()
        {
            parent::__construct();

            if(isset($_GET['id'])){
                $this->id = $this->decrypt($this->input->get('id'));
            }
            $this->data['controllerName'] = $this->controller;
        }

        function index()
        {
            $whereSearchedText = '';
            $searchedText =$this->input->post('searchedText');
            if($searchedText != '')
            {
                $whereSearchedText = " AND p.`name` LIKE '%".$searchedText."%'";
            }

            $wheredate = '';
            $startDate = $this->input->post('startDate');
            $endDate = $this->input->post('endDate');

            if($startDate !='')
            {
                $wheredate .= " AND i.date >= '".strtotime($startDate)."' ";
            }

            if($endDate !='')
            {
                $wheredate .= " AND i.date <= '".strtotime($endDate)."' ";
            }

            if($this->id > 0 && $whereSearchedText == '')
            {
                $row = $this->select('', $this->table4, 'id ='.$this->id)->row();
                $this->headingText = 'Product Name : '.$row->name;

                $query = "SELECT i.id, i.`type_c` 'client_type', c.`name`, i.client_id, i.date, i.`type_i` 'type', i.`type_i` 'invoice_type', CONCAT('Invoice(', (i.`id`), ')') 'invoice_detail', SUM(CASE WHEN i.`type_i` = 3 AND id.`product_id` = '" .  $this->id . "' THEN id.`qty` ELSE 0 END) 'debit', SUM(CASE WHEN i.`type_i` = 2 AND id.`product_id` = '" .  $this->id . "' THEN id.`qty` ELSE 0 END) 'credit', 'balance' FROM `products` p INNER JOIN `invoice_detail` id ON p.`id` = id.`product_id` INNER JOIN invoice i ON i.`id` = id.`invoice_id` INNER JOIN `clients` c ON c.`id` = i.`client_id` WHERE i.`status` = '1' AND id.`status` = '1' AND (i.`type_i` = 2 OR i.`type_i` = 3) AND p.`id` = '" .  $this->id . "' $wheredate GROUP BY i.`id` ORDER BY i.`date` DESC";
                //$query = "SELECT i.id, i.`type_c` 'client_type', c.`name`, i.client_id, i.date, i.`type_i` 'type', i.`type_i` 'invoice_type', CONCAT('Invoice(', (i.`id`), ')') 'invoice_detail', SUM(CASE WHEN i.`type_i` = 3 AND id.`product_id` = '411' THEN id.`qty` ELSE 0 END) 'debit', SUM(CASE WHEN i.`type_i` = 2 AND id.`product_id` = '411' THEN id.`qty` ELSE 0 END) 'credit', 'balance' FROM `products` p INNER JOIN `invoice_detail` id ON p.`id` = id.`product_id` INNER JOIN invoice i ON i.`id` = id.`invoice_id` INNER JOIN `clients` c ON c.`id` = i.`client_id` WHERE i.`status` = '1' AND id.`status` = '1' AND (i.`type_i` = 2 OR i.`type_i` = 3) GROUP BY i.`id` ORDER BY i.`date` DESC";
                //$query = "select i.id, i.`type_c` 'client_type', c.`name`, i.client_id, i.date, i.`type_i` 'type', i.`type_i` 'invoice_type', CONCAT('Invoice(', (i.`id`), ')') 'invoice_detail', SUM(CASE WHEN i.`type_i` = 1 AND id.`product_id` = '".$this->id . "' THEN id.`qty` ELSE 0 END) 'debit', SUM(CASE WHEN (i.`type_i` = 2 OR i.`type_i` = 3) AND id.`product_id` = '".$this->id . "' THEN id.`qty` ELSE 0 END ) 'credit', SUM(CASE WHEN i.`type_i` = 1 THEN id.`qty` ELSE (- id.`qty`) END ) 'balance' from invoice i inner join invoice_detail id on i.`id` = id.`invoice_id` inner join `products` p on id.`product_id` = p.`id` inner join `clients` c on i.`client_id` = c.id where i.`status` = '1' and id.`status` = '1' and i.`id` in(select ii.`invoice_id` from invoice_detail ii where ii.`product_id` = '" .  $this->id . "') $wheredate group by i.`id`";
            }
            else
            {
                $query = "SELECT p.`id` 'id', p.`name`, CONCAT('Make (', SUM(CASE WHEN i.`type_i` = 3 THEN 1 ELSE 0 END),')',' & Sale (', SUM(CASE WHEN (i.`type_i` = 2) THEN 1 ELSE 0 END),')') 'detail', SUM(CASE WHEN i.`type_i` = 3 THEN id.`qty` ELSE (- id.`qty`) END) AS 'Reamining' FROM `products` p INNER JOIN `invoice_detail` id ON p.`id` = id.`product_id` INNER JOIN invoice i ON i.`id` = id.`invoice_id` WHERE i.`status` = '1' AND id.`status` = '1' $whereSearchedText $wheredate AND (i.`type_i` = 2 OR i.`type_i` = 3) GROUP BY p.`id` ORDER BY p.`name`";
                //$query = "SELECT p.`id` 'id', p.`name`, CONCAT('Purchase (', SUM(CASE WHEN i.`type_i` = 1 THEN 1 ELSE 0 END),')',' & Sale (', SUM(CASE WHEN (i.`type_i` = 2) THEN 1 ELSE 0 END),')') 'detail', SUM(CASE WHEN i.`type_i` = 1 THEN id.`qty` ELSE (- id.`qty`) END) AS 'Reamining' FROM `products` p INNER JOIN `invoice_detail` id ON p.`id` = id.`product_id` INNER JOIN invoice i ON i.`id` = id.`invoice_id` WHERE i.`status` = '1' AND id.`status` = '1' $whereSearchedText $wheredate GROUP BY p.`id` ORDER BY p.`name`";
            }


            $temp             = new template();
            $temp->query      = $query;
            $temp->action      = false;
            $temp->controller = $this->controller;
            $temp->headingText = $this->headingText;

            $pageNo = $this->getUrlValue(4);
            if(!empty($pageNo))
            {
                $temp->pageNo = $pageNo;
            }

            $this->loadView($temp->pagination(), $this->data);
        }
    }


    ?>