<?php

    class Account_Ledger extends Admin_Controller
    {
        var $controller = 'account_ledger';

        var $table = 'invoice';
        var $table2 = 'invoice_detail';
        var $table3 = 'invoice_items';
        var $table4 = 'items';
        var $table5 = 'products';
        var $table6 = 'clients';

        var $data = array();

        function __construct()
        {
            parent::__construct();
            $this->data['controllerName'] = $this->controller;
        }

        function index()
        {
            $startDate = strtotime($_POST['startDate']);
            $endDate = strtotime($_POST['endDate']);

            $where = '';
            if($startDate > 0) {
                $where .= ' AND i.`date` >= '.$startDate;
            }

            if($endDate > 0) {
                $where .= ' AND i.`date` <= '.$endDate;
            }

            $query            = "SELECT i.id, type_c 'type', i.date, i.`type_i` 'invoice_type', c.`name`, i.`id` 'invoice_no', i.client_id, IF(i.`type_i` = 1 OR i.`type_i` = 3, FORMAT(i.total_amount, 2), '') 'credit', IF( i.`type_i` = 2, FORMAT(i.total_amount, 2), '') 'debit', 'balance' FROM invoice i INNER JOIN invoice_detail id ON i.id = id.invoice_id INNER JOIN clients c ON i.`client_id` = c.`id` WHERE i.`status` = '1' $where GROUP BY i.id ORDER BY i.`date`, i.`created_at`";

            $temp             = new template();
            $temp->action     = false;
            $temp->new        = false;
            $temp->pageNo     = 1;
            $temp->pageLimit  = 10000;
            $temp->query      = $query;
            $temp->controller = $this->controller;

            $this->loadView($temp->pagination(), $this->data);
        }
    }
